<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Karyawan</title>
    <!-- cdn bootstrap.css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body class="">
    <?php
        if (isset($_POST["submit"])) {
          $noPegawai = $_POST["noPegawai"];
          $namaPegawai = $_POST["namaPegawai"];
          $tanggalLahir = $_POST["tanggalLahir"];
          $tahunLahir = $_POST["tahunLahir"];
          $jk = $_POST["jk"];
          $statusPersonal = $_POST["statusPersonal"];
          $jabatan = $_POST["jabatan"];
          $kepegawaian = $_POST["kepegawaian"];
        }
           
        if ($jabatan == "Direktur" && $kepegawaian == "Tetap") {
              $gaji = 10000000;
        } else if ($jabatan == "Direktur" && $kepegawaian == "Kontrak"){
            $gaji = 8000000;
        } else if ($jabatan == "Manager" && $kepegawaian == "Tetap"){
            $gaji = 7000000;
        } else if ($jabatan == "Manager" && $kepegawaian == "Kontrak"){
            $gaji = 5000000;
        } else if ($jabatan == "Supervisor" && $kepegawaian == "Tetap"){
            $gaji = 3500000;
        } else if ($jabatan == "Supervisor" && $kepegawaian == "Kontrak"){
            $gaji = 3000000;
        } else if ($jabatan == "Coodinator" && $kepegawaian == "Tetap"){
            $gaji = 2500000;
        } else if ($jabatan == "Coodinator" && $kepegawaian == "Kontrak"){
            $gaji = 2000000;
        } else if ($jabatan == "Staff" && $kepegawaian == "Tetap"){
            $gaji = 1500000;
        } else if ($jabatan == "Staff" && $kepegawaian == "Kontrak"){
            $gaji = 1000000;
        } 
    ?>
    <!-- start container -->
    <div class="container my-4">

        <!-- title form -->
        <h2 class="text-center fw-bold">Data <?php echo "#". $noPegawai . " - " . $namaPegawai ?></h2>
        <h6 class="text-center mb-4 fst-italic">
            <?php
                echo "Tanggal : ". date("d-M-Y");
            ?>

        </h6>
        <!-- start form -->
        <div class="row justify-content-center">
            <div class="col-md-7 col-sm-12">
                <div class="row">
                    <!-- input noPegawai -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="noPegawai" class="col-md-3 col-sm-12 align-self-center">No Pegawai </label>
                        <input type="text" name="noPegawai" class="form-control bg-light" readonly
                            value="<?php echo $noPegawai ?>">
                    </div>
                    <!-- input namaPegawai -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="namaPegawai" class="col-md-3 col-sm-12 align-self-center">Nama Pegawai </label>
                        <input type="text" name="namaPegawai" class="form-control bg-light" readonly
                            value="<?php echo $namaPegawai ?>">
                    </div>
                    <!-- input tanggalahir -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="tanggalLahir" class="col-md-3 col-sm-12 align-self-center">Tgl - Tahun Lahir
                        </label>
                        <input type="text" name="tanggalLahir" class="form-control bg-light" readonly
                            value="<?php echo $tanggalLahir . " - " . $tahunLahir ?>">
                    </div>
                    <!-- input tahunlahir -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="tahunlahir" class="col-md-3 col-sm-12 align-self-center">Umur </label>
                        <input type="text" name="tahunlahir" class="form-control bg-light" readonly
                            value="<?php echo date("Y") - $tahunLahir . " tahun"?>">
                    </div>
                    <!-- pilih jenisKelamin -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="jk" class="col-md-3 col-sm-12 align-self-center">Jenis Kelamin </label>
                        <input type="text" name="jk" class="form-control bg-light" readonly value="<?php echo $jk ?>">
                    </div>
                    <!-- pilih statusPersonal -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="statusPersonal" class="col-md-3 col-sm-12 align-self-center">Status Personal</label>
                        <input type="text" name="statusPersonal" class="form-control bg-light" readonly
                            value="<?php echo $statusPersonal ?>">
                    </div>
                    <!-- pilih jabatan -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="jabatan" class="col-md-3 col-sm-12 align-self-center">Jabatan</label>
                        <input type="text" name="jabatan" class="form-control bg-light" readonly
                            value="<?php echo $jabatan ?>">
                    </div>
                    <!-- pilih kepegawaian -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="kepegawaian" class="col-md-3 col-sm-12 align-self-center">Status Pegawai</label>
                        <input type="text" name="kepegawaian" class="form-control bg-light" readonly
                            value="<?php echo $kepegawaian ?>">
                    </div>
                    <!-- pilih gaji -->
                    <div class="d-md-flex d-sm-block my-2">
                        <label for="gaji" class="col-md-3 col-sm-12 align-self-center">Status Pegawai</label>
                        <input type="text" name="gaji" class="form-control bg-light" readonly
                            value="<?php echo "Rp.    ". $gaji ?>">
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- end container -->
    <!-- cdn bootstrap.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</body>

</html>