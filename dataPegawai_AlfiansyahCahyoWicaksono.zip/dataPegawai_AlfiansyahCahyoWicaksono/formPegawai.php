<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data Karyawan</title>
    <!-- .css  -->
    <style>
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
    </style>
    <!-- cdn bootstrap.css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body class="">
    <!-- start container -->
    <div class="container my-4">

        <!-- title form -->
        <h2 class="text-center fw-bold">Formulir Data Pegawai</h2>
        <h6 class="text-center mb-4 fst-italic">
            <?php
                echo "Tanggal : ". date("d-M-Y");
            ?>

        </h6>
        <!-- start form -->
        <form action="dataFormPegawai.php" method="POST">
            <div class="row justify-content-center">
                <div class="col-md-7 col-sm-12">
                    <div class="row">
                        <!-- input noPegawai -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="noPegawai" class="col-md-3 col-sm-12 align-self-center">No Pegawai </label>
                            <input type="text" name="noPegawai" class="form-control bg-light" maxlength="5"
                                autocomplete="off" required>
                        </div>
                        <!-- input namaPegawai -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="namaPegawai" class="col-md-3 col-sm-12 align-self-center">Nama Pegawai </label>
                            <input type="text" name="namaPegawai" class="form-control bg-light" maxlength="25"
                                autocomplete="off" required>
                        </div>
                        <!-- input tanggalahir -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="tanggalLahir" class="col-md-3 col-sm-12 align-self-center">Tanggal Lahir
                            </label>
                            <input type="number" name="tanggalLahir" class="form-control bg-light" autocomplete="off"
                                required>
                        </div>
                        <!-- input tahunlahir -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="tahunLahir" class="col-md-3 col-sm-12 align-self-center">Tahun Lahir </label>
                            <input type="number" name="tahunLahir" class="form-control bg-light" autocomplete="off"
                                required>
                        </div>
                        <!-- pilih jenisKelamin -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="jk" class="col-md-3 col-sm-12 align-self-center">Jenis Kelamin </label>
                            <select name="jk" class="form-control bg-light" required>
                                <option selected disabled>-- Pilih Jenis Kelamin -- </option>
                                <option value="Pria">Pria</option>
                                <option value="Wanita">Wanita</option>
                            </select>
                        </div>
                        <!-- pilih statusPersonal -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="statusPersonal" class="col-md-3 col-sm-12 align-self-center">Status
                                Personal</label>
                            <select name="statusPersonal" class="form-control bg-light" required>
                                <option selected disabled>-- Pilih Status Personal -- </option>
                                <option value="Menikah">Menikah</option>
                                <option value="Belum Menikah">Belum Menikah</option>
                            </select>
                        </div>
                        <!-- pilih jabatan -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="jabatan" class="col-md-3 col-sm-12 align-self-center">Jabatan</label>
                            <div class="row">
                                <div class="col-4 col-md-4 col-lg-3 d-flex me-2">
                                    <input type="radio" name="jabatan" value="Direktur" checked><label
                                        class="mx-2">Direktur</label>
                                </div>
                                <div class="col-4 col-md-4 col-lg-3  d-flex  me-2">
                                    <input type="radio" name="jabatan" value="Manager"><label
                                        class="mx-2">Manager</label>
                                </div>
                                <div class="col-4 col-md-4 col-lg-3 d-flex  me-2">
                                    <input type="radio" name="jabatan" value="Supervisor"><label
                                        class="mx-2">Supervisor</label>
                                </div>
                                <div class="col-4 col-md-4 col-lg-3 d-flex  me-2">
                                    <input type="radio" name="jabatan" value="Coordinator"><label
                                        class="mx-2">Coordinator</label>
                                </div>
                                <div class="col-4 col-md-4 col-lg-3 d-flex me-2">
                                    <input type="radio" name="jabatan" value="Staff"><label class="mx-2">Staff</label>
                                </div>

                            </div>
                        </div>
                        <!-- pilih kepegawaian -->
                        <div class="d-md-flex d-sm-block my-2">
                            <label for="kepegawaian" class="col-md-3 col-sm-12 align-self-center">Status Pegawai</label>
                            <div class="row">
                                <div class="col-3 col-md-3 col-lg-4 d-flex me-2">
                                    <input type="radio" name="kepegawaian" value="Tetap" checked><label
                                        class="mx-2">Tetap</label>
                                </div>
                                <div class="col-3 col-md-3 col-lg-4 d-flex me-2">
                                    <input type="radio" name="kepegawaian" value="Kontrak"><label
                                        class="mx-2">Kontrak</label>
                                </div>

                            </div>
                        </div>
                        <!-- button submit form -->
                        <div class="d-flex my-2">
                            <input type="submit" name="submit" value="Submit" class="btn btn-primary w-100 fw-bold">
                        </div>
                    </div>

                </div>
            </div>
        </form>
        <!-- end form -->
    </div>
    <!-- end container -->
    <!-- cdn bootstrap.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</body>

</html>